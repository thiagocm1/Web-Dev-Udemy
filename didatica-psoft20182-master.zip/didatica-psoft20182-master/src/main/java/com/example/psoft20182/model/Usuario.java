package com.example.psoft20182.model;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonSubTypes;
@Entity(name = "usuario")
@Table(name = "tb_usuario")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@JsonSubTypes({@JsonSubTypes.Type(value = Cliente.class, name = "CLIENTE"), 
			   @JsonSubTypes.Type(value = Administrador.class, name = "ADMINISTRADOR")
})

public abstract class Usuario {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "nome")
	@NotNull(message = "Nome nao pode ser nulo")
	@NotEmpty(message = "Nome nao pode ser vazio")
	private String nome;
	@Column(name = "cpf")
	private String cpf;
	@Column(name = "email")
	private String email;
	@Column(name = "senha")
	private String senha;
	@Column (name = "aniversario")
	private Date aniversario;
	
	
	public Usuario(String nomeUsuario, String cpfUsuario, Date aniversario,String emailUsuario, String senhaUsuario) {
		this.nome = nomeUsuario;
		this.cpf = cpfUsuario;
		this.email = emailUsuario;
		this.senha = senhaUsuario;
		this.aniversario = aniversario;
	}

	abstract void login();
	abstract void cadastra();
	
	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getCpf() {
		return cpf;
	}


	public void setCpf(String cpf) {
		this.cpf = cpf;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getSenha() {
		return senha;
	}


	public void setSenha(String senha) {
		this.senha = senha;
	}


	public Date getAniversario() {
		return aniversario;
	}


	public void setAniversario(Date aniversario) {
		this.aniversario = aniversario;
	}
	
	
}
