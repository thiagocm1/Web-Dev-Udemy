package com.example.psoft20182.model;

public class Administrador {

}
